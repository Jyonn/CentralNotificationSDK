from CentralNotificationSDK.notificator import Notificator


__all__ = [
    Notificator
]
